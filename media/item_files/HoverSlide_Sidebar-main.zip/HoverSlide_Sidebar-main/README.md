# HoverSlide_Sidebar
A collapsible sidebar that expands on mouse hover. HTML and CSS only! 
