<?php
    $firstname = $_POST['firstname'];
    $Lastname = $_POST['Lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $Confirmpassword = $_POST['Confirm password'];


    //Database connection
    $conn = new mysqli('localhost', 'root', '','test 3');
    if($conn->connect_error){
        die('Connection Failed : ' .$conn->connect_error);
    }else{
        $stmt = $conn->prepare("insert into registration(firstname, Lastname, email, password, confirm password) values(?, ?, ?, ?, ?)");
        $stmt->blind_param("sssss" $firstname, $Lastname, $email, $password, $Confirmpassword);
        $stmt->execute();
        echo "registration successful...";
        $stmt->close();
        $conn->close();
    }
?>